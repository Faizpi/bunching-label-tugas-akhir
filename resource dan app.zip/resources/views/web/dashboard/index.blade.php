@extends('web.layout.main')

@section('content')
<!-- Info boxes -->
<div class="row">
    <div class="col-sm-6 col-xs-12">
        <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-users"></i></span>

            <div class="info-box-content">
            <span class="info-box-text">Jumlah Operator</span>
            <span class="info-box-number">1</span>
            </div>
            <!-- /.info-box-content -->
        </div>
        <!-- /.info-box -->
    </div>
    <!-- /.col -->
    <div class="col-sm-6 col-xs-12">
        <div class="info-box">
            <span class="info-box-icon bg-red"><i class="fa fa-newspaper-o"></i></span>

            <div class="info-box-content">
            <span class="info-box-text">Jumlah Label</span>
            <span class="info-box-number">0</span>
            </div>
            <!-- /.info-box-content -->
        </div>
        <!-- /.info-box -->
    </div>
    <!-- /.col -->
</div>

<div class="row" style="margin-top: 3rem">
    <div class="col-sm-4 col-sm-offset-4">
        <div class="panel panel-default">
            <div class="panel-body">
                <form method="post" action="{{route('web.dashboard.print')}}" target="_blank">
                    {{csrf_field()}}
                    <div class="form-group">
                        <label for="exampleInputEmail1">Type/Size</label>
                        <input type="email" name="size" class="form-control" id="exampleInputEmail1" value="AVSS 2.0 SQ 37/0.260" readonly>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Length (meter)</label>
                        <input type="number" name="length" class="form-control" id="exampleInputPassword1" placeholder="Length" required>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Weight (Kg)</label>
                        <input type="number" name="weight" class="form-control" id="exampleInputPassword1" placeholder="Weight" required>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Date</label>
                        <input type="text" name="shift_date" data-type="datetime" class="form-control" placeholder="2020-01-24" required>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Shift</label>
                        <input type="text" name="shift" class="form-control" placeholder="shift" required>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Machine No</label>
                        <input type="text" name="machine_number" id="machine_number" class="form-control" id="exampleInputPassword1" placeholder="Machine No" required>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Pitch (mm)</label>
                        <input type="number" name="pitch" class="form-control" id="exampleInputPassword1" placeholder="Pitch" required>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Direction</label>
                        <input type="text" name="direction" class="form-control" id="exampleInputPassword1" value="S" placeholder="Direction" readonly>
                    </div>        
                    <div class="form-group">
                        <label for="exampleInputPassword1">Visual</label>
                        <div class="radio">
                            <label>
                                <input name="visual" value="OK" type="radio" checked> OK
                            </label>
                        </div>
                        <div class="radio">
                            <label>
                                <input name="visual" value="NG" type="radio"> NG
                            </label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Remark</label>
                        <input type="text" name="remark" class="form-control" id="exampleInputPassword1" placeholder="Remark" oninvalid="this.setCustomValidity('Please Enter valid email')"
							oninput="setCustomValidity('')">
                    </div>
                    
                    <div class="form-group">
                        <label for="exampleInputPassword1">No Bobin</label>
                        <input type="text" name="bobin_no" value="" class="form-control" id="exampleInputPassword1" placeholder="No Bobin" required>
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-block">Print</button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection


@push('styles')
<link rel="stylesheet" href="{{asset('css/bootstrap-datepicker3.min.css')}}">
<link rel="stylesheet" href="{{asset('bundle/bootstrap-datetimepicker/css/bdt.css')}}">
@endpush

@push('scripts')
<script src="{{asset('js/bootstrap-datepicker.min.js')}}"></script>
<script src="{{asset('bundle/moment/min/moment.min.js')}}"></script>
<script src="{{asset('bundle/bootstrap-datetimepicker/js/bdt.js')}}"></script>
<script>
    $('[data-type=date]').datepicker({
        timePicker: true,
        format: 'yyyy-mm-dd',
        autoclose: true,
        zIndexOffset: 1500
    });

    $('[data-type=datetime]').datetimepicker({
        format: 'YYYY-MM-DD',
    });
</script>
@endpush